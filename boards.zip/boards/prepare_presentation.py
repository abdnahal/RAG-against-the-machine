"""Arrange codex-tldraw's generated diagrams and export a local slide viewer."""
from pathlib import Path
import collections
import copy
import html
import json
import xml.etree.ElementTree as ET

B = Path(__file__).resolve().parent
board_path = B / 'rag-pipeline-guide.tldr'
svg_path = B / 'rag-pipeline-guide.svg'
raw = B / '.layout-source'
raw.mkdir(exist_ok=True)
for path in (board_path, svg_path):
    target = raw / path.name
    if not target.exists():
        target.write_bytes(path.read_bytes())
board = json.loads((raw / board_path.name).read_text())
root = ET.fromstring((raw / svg_path.name).read_text())
ns = 'http://www.w3.org/2000/svg'
ET.register_namespace('', ns)
groups = collections.defaultdict(list)
for record in board['records']:
    meta = record.get('meta', {}).get('tldrawMcp', {})
    if meta.get('diagramId'):
        groups[meta['diagramId']].append(record)

ordered = sorted(groups, key=lambda key: groups[key][0]['meta']['tldrawMcp']['repoName'])
evidence = {
1: ['src/__main__.py:main', 'src/cli.py:RagCLI', 'src/api.py'],
2: ['src/indexer.py:index_corpus', 'src/indexer.py:collect_chunks'],
3: ['src/chunking.py:chunk_file', 'src/chunking.py:chunk_markdown', 'src/chunking.py:chunk_code'],
4: ['src/retriever.py:make_chunk_id', 'src/retriever.py:build_postings', 'src/retriever.py:search', 'src/retriever.py:bm25_term_score'],
5: ['src/semantic.py:build_semantic_index', 'src/cli.py:RagCLI.index'],
6: ['src/semantic.py:search_semantic', 'src/hybrid.py:fuse_rankings', 'src/indexer.py:search_saved_index'],
7: ['src/cache.py', 'src/indexer.py:search_saved_index'],
8: ['src/indexer.py:index_corpus', 'src/cli.py:RagCLI.index'],
9: ['src/generation.py', 'src/cli.py:RagCLI.answer'],
10: ['src/cli.py:RagCLI.search_dataset', 'src/cli.py:RagCLI.answer_dataset', 'src/models.py'],
11: ['src/evaluation.py', 'src/cli.py:RagCLI.evaluate'],
12: ['src/api.py', 'src/models.py:QueryRequest'],
13: ['pyproject.toml', 'src/__main__.py', 'src/models.py', 'src/chunking.py', 'src/api.py'],
14: ['pyproject.toml', 'src/semantic.py', 'src/generation.py', 'src/cache.py'],
15: ['src/indexer.py:search_saved_index', 'src/generation.py'],
}
svg_shapes = {g.attrib['data-shape-id']: g for g in root.iter() if 'data-shape-id' in g.attrib}
slides = []
width = 0
slide_dir = B / 'slides'
slide_dir.mkdir(exist_ok=True)
for number, diagram_id in enumerate(ordered, 1):
    records = groups[diagram_id]
    title = records[0]['meta']['tldrawMcp']['repoName']
    x0, y0 = min(r['x'] for r in records), min(r['y'] for r in records)
    max_x = max(r['x'] + r['props'].get('w', 0) for r in records)
    geo_bottom = max(r['y'] + r['props'].get('h', 48) for r in records)
    # Include routed arrow endpoints and their label clearance.
    for r in records:
        for point in ('start', 'end'):
            if point in r['props']:
                max_x = max(max_x, r['x'] + r['props'][point]['x'])
                geo_bottom = max(geo_bottom, r['y'] + r['props'][point]['y'] + 32)
    w, h = max_x - x0 + 128, max(420, geo_bottom - y0 + 128)
    width = max(width, w)
    slide = ET.Element(f'{{{ns}}}svg', {'width': str(w), 'height': str(h), 'viewBox': f'0 0 {w} {h}', 'role': 'img', 'aria-label': title})
    ET.SubElement(slide, f'{{{ns}}}rect', {'width': '100%', 'height': '100%', 'fill': '#fff'})
    layer = ET.SubElement(slide, f'{{{ns}}}g', {'font-family': 'Inter, ui-sans-serif, system-ui, sans-serif'})
    for r in records:
        original = svg_shapes.get(r['id'])
        if original is not None:
            element = copy.deepcopy(original)
            element.set('transform', f'translate({-x0},{-y0})')
            layer.append(element)
            original.set('transform', f'translate({-x0},{(number-1)*640-y0})')
        r['x'] -= x0
        r['y'] += (number-1)*640-y0
        r['meta']['tldrawMcp']['evidence'] = evidence[number]
    file_name = f'{number:02d}.svg'
    ET.ElementTree(slide).write(slide_dir / file_name, encoding='utf-8', xml_declaration=True)
    slides.append({'title': title, 'file': f'slides/{file_name}', 'svg': ET.tostring(slide, encoding='unicode')})

root.set('width', str(width))
root.set('height', str(len(ordered)*640))
root.set('viewBox', f'0 0 {width} {len(ordered)*640}')
board_path.write_text(json.dumps(board, ensure_ascii=False, indent=2))
ET.ElementTree(root).write(svg_path, encoding='utf-8', xml_declaration=True)

sections = '\n'.join(f'<section class="slide" aria-label="{html.escape(s["title"])}">{s["svg"]}</section>' for s in slides)
options = ''.join(f'<option value="{i}">{html.escape(s["title"])}</option>' for i, s in enumerate(slides))
page = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RAG pipeline — peer evaluation</title><style>
*{box-sizing:border-box}body{margin:0;font:16px system-ui,sans-serif;background:#edf1f7;color:#172337}
header{background:#14233b;color:white;padding:18px 24px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
h1{font-size:20px;margin:0}header a{color:#d4e7ff}nav{display:flex;gap:10px;align-items:center;padding:16px 24px;flex-wrap:wrap}
button,select{font:inherit;border:1px solid #b7c5d8;border-radius:8px;padding:9px;background:white;color:#14233b}select{max-width:75vw}
button{cursor:pointer}button:disabled{opacity:.4;cursor:default}.slide{display:none;background:white;margin:0 24px 20px;border-radius:14px;border:1px solid #d5deea;padding:10px;overflow:auto;min-height:56vh;align-items:center}
.slide.active{display:flex}.slide svg{display:block;width:100%;min-width:2400px;height:auto}footer{padding:0 24px 24px;color:#4e617c;line-height:1.6}
@media print{header,nav,footer{display:none}.slide{display:block;break-after:page;border:none;margin:0;padding:0;min-height:0}.slide svg{min-width:0;width:100%}@page{size:A3 landscape;margin:10mm}}
</style><header><h1>RAG against the machine · Pipeline walkthrough</h1><a href="PEER_EVALUATION.md">Detailed speaker notes</a><a href="rag-pipeline-guide.tldr">Editable tldraw board</a></header>
<nav aria-label="Slide navigation"><button id="prev">← Previous</button><select id="select" aria-label="Choose a section">OPTIONS</select><button id="next">Next →</button><span id="count" aria-live="polite"></span></nav>
<main>SECTIONS</main><footer>Use ← / → to move between sections. Scroll horizontally or zoom in to read details. Print to PDF for all 15 diagrams.<br>Generated with codex-tldraw from the source inspected on 2026-11-03. Application code unchanged.</footer>
<script>const slides=[...document.querySelectorAll('.slide')],select=document.getElementById('select');let current=0;function show(i){current=Math.max(0,Math.min(slides.length-1,i));slides.forEach((s,j)=>s.classList.toggle('active',j===current));select.value=current;document.getElementById('prev').disabled=current===0;document.getElementById('next').disabled=current===slides.length-1;document.getElementById('count').textContent=`${current+1} / ${slides.length}`;}document.getElementById('prev').onclick=()=>show(current-1);document.getElementById('next').onclick=()=>show(current+1);select.onchange=()=>show(Number(select.value));document.addEventListener('keydown',e=>{if(e.target.tagName==='SELECT')return;if(e.key==='ArrowRight')show(current+1);if(e.key==='ArrowLeft')show(current-1)});show(0);</script></html>'''
(B / 'presentation.html').write_text(page.replace('OPTIONS', options).replace('SECTIONS', sections))
(B / 'sections.json').write_text(json.dumps([{'title': s['title'], 'file': s['file'], 'evidence': evidence[i]} for i,s in enumerate(slides,1)], ensure_ascii=False, indent=2))
print(f'Arranged {len(slides)} sections vertically; wrote per-section SVGs and presentation.html')
