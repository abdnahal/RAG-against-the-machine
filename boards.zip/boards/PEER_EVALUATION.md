# RAG against the machine — peer evaluation guide

This guide describes the current `src/` implementation inspected on 2026-11-03. The diagrams were created with **codex-tldraw**. This is an explanation of the implementation, not a new certification that every requirement or edge case passes. Application code was not changed for this guide.

Open [the editable board](rag-pipeline-guide.tldr), [the SVG overview](rag-pipeline-guide.svg), or [the presentation](presentation.html). The numbered sections below follow the board. The presentation supports the arrow keys and includes a link to these notes.

## Your opening explanation

> “My project answers questions about the vLLM repository using retrieval-augmented generation. First I split source files into traceable chunks and build a local search index. For a question, I retrieve relevant chunks using BM25, semantic search, or hybrid retrieval. I can return the source locations directly, or pass the evidence to Qwen to generate an answer. I also implement incremental indexing, caching, dataset commands, retrieval evaluation, and an HTTP API.”

The project uses pretrained models for inference. It does **not** train Qwen on the repository. Retrieval selects evidence; generation interprets that evidence. Those two stages can fail independently.

## 01 — Entry points and the complete runtime path

[`src/__main__.py`](../src/__main__.py) is the actual `python -m src` entry point. `Fire(RagCLI)` exposes the public methods of [`RagCLI`](../src/cli.py) as commands. `main()` prints exceptions to stderr and exits with status 1; a keyboard interrupt exits with 130. The greeting in `src/__init__.py:main()` is not this command dispatcher.

| Command | Input | Work | Output |
|---|---|---|---|
| `index` | Corpus directory, chunk-size limit, optional semantic flag | Build/update chunks and indexes | Local index files and success message |
| `search` | Question, k, method | Retrieve sources | JSON containing one result in `search_results` |
| `search_dataset` | Question dataset | Retrieve for each question | Search-results JSON using the input filename |
| `evaluate` | Saved search results and answered dataset | Compute mean source Recall@k | Printed score |
| `answer` | Question, k, method | Retrieve, build prompt, generate | Answer printed and saved to `results.json` |
| `answer_dataset` | **Saved search-results JSON** | Reconstruct source text and generate answers | Answer-results JSON using the input filename |

The usual single-question call chain is:

```text
RagCLI.answer()
  -> search_saved_index()
     -> read revision / check required files / try query cache
     -> search() and/or search_semantic()
     -> optional fuse_rankings()
  -> load_llm()
  -> build_messages() -> build_context()
  -> generate_answer()
  -> MinimalAnswer -> StudentSearchResultsAndAnswer -> JSON + print
```

`search()` at the CLI level and `retriever.search()` are different functions: the first handles a user command and serializes results; the second calculates BM25 rankings.

## 02 — Discover files and detect changes

[`indexer.index_corpus()`](../src/indexer.py) validates that the corpus directory exists, stores the corpus path relative to the working directory, and creates the processed directory. `discover_files()` walks the directory recursively with `Path.rglob()` and selects `.py`, `.md`, `.txt`, and `.rst` files. `tqdm` displays progress.

`file_hash()` computes SHA-256 from each file's bytes. The previous path-to-hash mapping comes from `map.json`. Comparing the old and current mappings yields:

| State | Meaning | Result |
|---|---|---|
| Added | Current path has no old entry | Chunk and index this file |
| Modified | Same path, different content hash | Replace its old chunks and index entries |
| Deleted | Old path no longer exists | Remove its chunks and index entries |
| Unchanged | Same path and hash | Reuse saved chunks |

`collect_chunks()` returns the chunks for **all currently discovered files**, reusing unchanged ones. Deleted files therefore do not reappear in the new chunk list. `save_map()` writes current file hashes plus `max_chunk_size`.

**What to say:** “The hash tells me whether file contents changed. I avoid splitting unchanged files again. I still scan and hash the corpus to detect changes.”

## 03 — Chunking and source offsets

[`chunking.chunk_file()`](../src/chunking.py) dispatches `.py` files to `chunk_code()`. The other discovered file types use `chunk_markdown()`.

`chunk_markdown()` keeps newline characters with `splitlines(keepends=True)`. It accumulates lines, flushes a nonempty buffer before a heading or a size overflow, splits an oversized line into bounded slices, and flushes the remaining buffer at the end. Its heading rule is simply `line.startswith('#')`; it is not a complete Markdown parser and does not track fenced-code-block state.

`chunk_code()` uses `PythonCodeTextSplitter` from `langchain_text_splitters`. This is a recursive, Python-aware text splitter; your implementation does **not** construct an AST. The options have specific purposes:

| Option | Purpose in your code |
|---|---|
| `chunk_size=max_chunk_size` | Bound the text chunks by character length |
| `chunk_overlap=0` | Request no repeated overlap between chunks |
| `keep_separator=True` | Keep splitting separators in the resulting text |
| `strip_whitespace=False` | Preserve source whitespace for offset consistency |
| `add_start_index=True` | Include the start position in each document's metadata |

`create_documents([content])` produces documents. Your code uses `doc.page_content`, reads `doc.metadata['start_index']`, computes `end = start + len(text)`, and creates a Pydantic `Chunk`.

```text
Chunk = text + file_path + first_character_index + last_character_index
text = original_file_content[start:end]
```

The interval is **half-open**: start is included, end is excluded. Despite the field name, `last_character_index` is not the position of the last included character. `[10, 15)` contains five characters. These are Python string positions in the text read by the program, not UTF-8 byte offsets and not model token positions.

`save_chunks()` converts models to dictionaries with `model_dump()` before writing JSON. `load_chunks()` validates each saved dictionary with `Chunk.model_validate()`.

## 04 — BM25 indexing and scoring

[`retriever.make_chunk_id()`](../src/retriever.py) hashes a JSON representation of `[file_path, start, end, text]`. `map_chunk()` creates `chunk_id -> Chunk`. Changing the path, text, or offsets changes the ID. This is distinct from the whole-file hash, the semantic vector's row number, and the language model's token IDs.

`tokenize()` lowercases text, extracts alphanumeric pieces, and also retains whole identifiers containing underscores. For example, `skip_sampler_cpu_output` contributes `skip`, `sampler`, `cpu`, `output`, and `skip_sampler_cpu_output`. This supports both partial and exact identifier matches. It does not perform stemming, stop-word removal, or special camelCase splitting.

`build_postings()` tokenizes **chunk text plus the filename**, uses `Counter` through `counted()`, and creates three structures:

```text
chunk_lengths = {chunk_id: number_of_tokens}
chunk_terms   = {chunk_id: {term: term_frequency}}
postings      = {term: {chunk_id: term_frequency}}
```

`postings` is the inverted index: start from a query term and jump to the chunks containing it. `chunk_terms` is useful when removing an old chunk: it lists which posting lists need updating. `save_bm25_index()` persists all three; `load_bm25_index()` restores them.

For each distinct query term, `search()` looks up its posting list and adds `bm25_term_score()` to each matching chunk's score:

```text
IDF(term) = ln(1 + (N - df + 0.5) / (df + 0.5))

term_score = IDF(term) * tf * (k1 + 1)
             / (tf + k1 * (1 - b + b * length / avg_length))

chunk_score = sum(term_score for matching unique query terms)
```

`N` is the number of indexed, nonempty chunks, `df` the number containing the term, `tf` its frequency in the candidate, and `length` the candidate's token count. The current search uses `k1=1.2` and `b=0.75`. A rare matching term contributes more; repeated occurrences have diminishing benefit; length adjustment reduces the advantage of longer chunks. The local variable `N` inside `search()` actually holds the **sum of token lengths**, used to calculate the average; the document count passed to the scoring function is `len(chunk_lengths)`.

Example: with 10 indexed chunks, a term found in 2, `tf=3`, candidate length 100 and average length 80, IDF is approximately 1.482 and the term contributes approximately **2.210**. Final scores are sorted descending and mapped back to the top-k `Chunk` objects. A query with no matching postings produces no BM25 results.

**What to say:** “BM25 is my own scoring and inverted-index code. LangChain is used for splitting Python files, not for implementing BM25.”

## 05 — Semantic embeddings and incremental vector updates

[`semantic.load_embedding_model()`](../src/semantic.py) loads `sentence-transformers/all-MiniLM-L6-v2` on the CPU. `@lru_cache(maxsize=1)` reuses it within the current process. This model creates retrieval vectors; it is separate from Qwen, which generates answers.

For each chunk, your embedding input is `File: <file_path>\n\n<chunk.text>`. The path is extra retrieval context, not a modification to the original source text or its offsets. A full build calls `encode_document()` with normalization enabled, NumPy output, and `batch_size=8`. The model maps text to dense vectors; the empty-index case explicitly uses shape `(0, 384)`. The actual nonempty dimension is recorded from the output matrix. [Sentence Transformers API](https://sbert.net/docs/package_reference/sentence_transformer/model.html).

The stored relationship is:

```text
manifest.chunk_ids[i] -> chunk ID -> current Chunk
embeddings.npy[i]     -> vector for that same chunk
```

For example, old IDs `[A, B, C]` align with rows `[vA, vB, vC]`. If B is removed and D is added, the saved IDs might be `[A, C, D]` with rows `[vA, vC, vD]`. The old row number is not a permanent identity. The manifest makes the relationship explicit.

`RagCLI.index(semantic=True)` loads the old semantic state **before** `index_corpus()` changes the revision. It then passes that old state and the change report into `build_semantic_index()`:

1. Build `current_map` and `current_ids` from the current saved chunks.
2. If a reusable old index exists and no rebuild is required, iterate current IDs.
3. For chunks in added/modified files, call `model.encode()` on the prefixed text.
4. Otherwise reuse `old_embeddings[old_ids.index(chunk_id)]`.
5. Stack rows in current-ID order and save the complete matrix and manifest.

Deleted chunks disappear because only current IDs are emitted. Unchanged embeddings are reused even though the `.npy` file is rewritten. This is **incremental computation**, not an in-place update of only a few bytes on disk. The current incremental path encodes changed chunks individually and uses a linear `old_ids.index()` lookup; it does not batch those changes or use an ID-to-row dictionary.

## 06 — Semantic retrieval and hybrid RRF

`read_semantic_manifest()` checks required fields, a nonempty current revision, the expected model name, a positive dimension, and a unique list of string chunk IDs. `load_semantic_index()` checks files and calls the revision-keyed loader. `_load_semantic_for_revision()` uses `np.load(..., allow_pickle=False)`, checks matrix dimensions and row count, and confirms that every manifest ID exists in the current chunk map.

`search_semantic()` encodes the question using `encode_query(..., normalize_embeddings=True)`, calculates `model.similarity(embeddings, encoded)`, removes the singleton query dimension with `squeeze(1)`, and uses `torch.topk()` to find the best rows. It caps k at the number of available chunks. Rows are mapped through manifest IDs back to chunks. The library's default similarity is cosine; normalized vectors make their dot product equal to cosine similarity. There is no explicit relevance-score threshold in your function. [Sentence Transformers API](https://sbert.net/docs/package_reference/sentence_transformer/model.html).

For `method='hybrid'`, [`search_saved_index()`](../src/indexer.py) retrieves `max(20, k)` candidates from **each** branch. [`hybrid.fuse_rankings()`](../src/hybrid.py) combines rankings using reciprocal rank fusion:

```text
RRF(chunk) = sum(1 / (60 + rank_in_branch))
```

Ranks start at 1. A chunk at BM25 rank 1 and semantic rank 3 receives `1/61 + 1/63 ≈ 0.03227`. A chunk found only at semantic rank 1 receives `1/61 ≈ 0.01639`. The code deduplicates by chunk ID and returns the highest-scoring k chunks. It combines **positions**, not raw BM25 and similarity scores, which have different scales. Hybrid retrieval can still rank a less useful chunk higher; it does not guarantee an increase in recall.

## 07 — The caches and revision numbers

[`cache.write_index_revision()`](../src/cache.py) writes a fresh UUID into `metadata.json`. This is a version marker for saved state, not an incrementing counter and not the file-content hash. `read_index_revision()` validates the metadata before returning it.

| Cache | Stored value | Lifetime / key |
|---|---|---|
| `_load_index_for_revision()` | Parsed chunks, ID map, lengths, postings | Process memory; directory + revision; one entry |
| `_load_semantic_for_revision()` | IDs, vector matrix, chunk map | Process memory; directory + revision + model; one entry |
| `load_embedding_model()` / `load_llm()` | Loaded pretrained models/tokenizer | Current Python process |
| Query cache JSON | Ranked full `Chunk` objects | Disk; request + index revision |
| `answer_dataset()` file cache | Original source-file text | One dataset-answer invocation |

`make_query_cache_key()` hashes a sorted JSON payload containing resolved index directory, revision, **raw query text**, k, lowercase method, and `retrieval_version='v2'`. Query text is not normalized: changing whitespace or case can produce another cache entry. The path is `cache/queries/<revision>/<hash>.json`.

`search_saved_index()` validates required files and semantic freshness before returning a query-cache hit. `read_query_cache()` returns `None` for a missing or malformed entry and validates cached objects through Pydantic. An empty list is a valid cached result; the caller checks `is not None`. A miss triggers retrieval, then `write_query_cache()` writes the chunks.

**What to say:** “A new index revision changes both the memory-cache key and disk-cache location, so an old result is not reused for the new index.” Old cache directories are not automatically deleted. Query caching saves retrieval work; it does **not** cache generated answers. A separate CLI process reloads its in-memory model cache.

## 08 — When indexing skips work, updates, or rebuilds

The initial build needs `chunks.json`, `map.json`, `bm25.json`, and `metadata.json`. A missing required artifact sets `rebuild=True`; a changed chunk-size setting also triggers a rebuild and fresh chunking. For a missing BM25 artifact with otherwise usable saved state, existing unchanged chunks can still be reused while postings are rebuilt.

On a normal incremental run, `index_corpus()` removes old IDs belonging to modified/deleted files from `chunk_lengths`, `chunk_terms`, and their posting lists. Empty posting lists are deleted. It builds postings only for chunks in added/modified files and merges those structures into the surviving index.

If no rebuild is needed and no files changed, it returns early without rewriting BM25 or changing the revision. Detection still involved discovery, hashing and collecting/reusing chunks. When state changes, it saves the new artifacts and writes the new revision. If semantic indexing was requested, the CLI builds vectors when the old semantic state is missing or the corpus changed/rebuilt.

If you update only BM25 after corpus changes, the old semantic manifest has the wrong revision and semantic/hybrid search rejects it until semantic indexing is refreshed. Checking model metadata is compatibility validation; reusing unchanged vectors is what makes the embedding computation incremental.

## 09 — Qwen generation and the Hugging Face calls

[`generation.build_context()`](../src/generation.py) numbers chunks from 1 and includes `[Source N]`, file path, character range, and source text. `build_messages()` returns two dictionaries: system instructions and a user message containing evidence plus the question. The system prompt asks for source-grounded, concise answers, exact code conditions, citations and abstention when evidence is insufficient.

`load_llm()` loads `AutoTokenizer` and `AutoModelForCausalLM` for `Qwen/Qwen3-0.6B`. `from_pretrained()` obtains the saved tokenizer/model configuration and weights from the model location/cache. The code explicitly selects float32 and CPU, calls `eval()`, and caches the loaded pair. There is no optimizer, loss calculation or training loop.

`apply_chat_template()` converts role/content messages to the model's expected chat sequence. `tokenize=True` produces token IDs, `add_generation_prompt=True` adds the assistant-start marker, `return_dict=True` returns named inputs, and `return_tensors='pt'` requests PyTorch tensors. `enable_thinking=False` is passed to Qwen's template. `.to(model.device)` puts inputs on the model's device. [Hugging Face chat templates](https://huggingface.co/docs/transformers/chat_templating).

`generate_answer()` checks that the output limit is a positive integer and that input-token count plus that limit is at most **32768**, the guard hard-coded in your function. `torch.inference_mode()` avoids autograd work during generation; `eval()` separately selects evaluation behavior for model layers.

| Generation argument | Current value | Meaning |
|---|---|---|
| `max_new_tokens` | 128 by default | Maximum generated tokens; excludes the prompt |
| `do_sample` | `True` | Sample from the next-token distribution |
| `temperature` | 0.7 | Adjust the distribution before sampling |
| `top_k` | 20 | Restrict candidate tokens to the highest-scoring group |
| `top_p` | 0.8 | Apply cumulative-probability filtering |

These are token-generation controls, not retrieval parameters. `top_k=20` here is unrelated to retrieving k source chunks. `generate()` extends the input sequence; slicing `output_ids[0, input_length:]` keeps only the new answer tokens. `decode(..., skip_special_tokens=True)` turns them into text. A maximum token limit can cut an answer off; the implementation does not explicitly report truncation. [Hugging Face generation reference](https://huggingface.co/docs/transformers/main_classes/text_generation).

The current production prompt/settings are described here. The experimental prompts from the earlier performance task are not integrated into this pipeline.

## 10 — Dataset input and output contracts

[`models.py`](../src/models.py) defines the contracts:

| Model | Fields / purpose |
|---|---|
| `Chunk` | Source text, path, start and end |
| `MinimalSource` | Path and offsets without text |
| `UnansweredQuestion` | `question_id`, `question`; UUID generated when ID omitted |
| `AnsweredQuestion` | Adds reference `sources` and `answer` |
| `RagDataset` | `rag_questions` containing question models |
| `MinimalSearchResults` | Question ID, question, retrieved source locations |
| `MinimalAnswer` | Adds generated answer to one search result |
| `StudentSearchResults` | `search_results` list plus k |
| `StudentSearchResultsAndAnswer` | Answer-result list plus k |
| `IndexData` | In-memory ID map, chunk lengths and postings |
| `QueryRequest` | Validated API query, k and method |

`search_dataset()` validates the input, rejects duplicate IDs and prevents overwriting the input path. It retrieves each question, converts chunks to `MinimalSource`, preserves IDs, and writes the result wrapper. It does not use reference answers to guide retrieval.

`answer_dataset()` consumes that saved result wrapper. It **does not search again**. It reads each referenced file once into `file_cache`, validates `0 <= start < end <= len(content)` and span length at most 2000, and reconstructs chunks with slicing. It rejects duplicate IDs and a result containing more than k sources. Empty questions or empty source lists produce explanatory text without model generation. Otherwise it builds messages, reuses cached Qwen, and saves answers with the original IDs and sources.

The source files must still represent the same content as when their offsets were recorded. Bounds checking alone cannot detect a changed file whose new length still accommodates an old span.

The student result wrappers have a `mode='before'` validator that converts integer strings such as `"54"` to integers before the strict nonnegative field check. API `QueryRequest.k` has no such converter and requires an actual JSON integer. `Literal` limits API methods to the three exact lowercase strings.

## 11 — Recall and source matching, with a worked example

[`evaluation.source_matches()`](../src/evaluation.py) first requires equal file-path strings. For two half-open intervals it computes:

```text
intersection = max(0, min(end1, end2) - max(start1, start2))
union = (end1 - start1) + (end2 - start2) - intersection
match = union > 0 and intersection / union >= 0.05
```

Expected `[100, 200)` and retrieved `[150, 250)` in the same file overlap by 50 characters. Their union is 150, giving `50/150 ≈ 0.333`, so they match. A different file never matches even if the intervals are identical.

`recall_for_question()` checks each expected source against `retrieved[:k]`. An expected source counts at most once even if several retrieved chunks match it:

```text
Recall@k(question) = matched expected sources / total expected sources
```

If a question has three expected sources and two are hit, recall is 2/3. If the next question has one expected source and it is hit, the mean is `(2/3 + 1) / 2 ≈ 0.833`. This is a mean of **per-question ratios**, not `3/4` from pooling all expected sources. Missing result IDs contribute zero recall through an empty retrieved list. Multiple expected spans can be matched by the same retrieved chunk if each independently passes the overlap rule.

`RagCLI.evaluate()` checks a nonempty answered dataset, expected source availability, duplicate/unknown IDs, valid offsets, retrieved spans no longer than 2000, and `requested_k <= saved_k`. It prints `Recall@k: ...` rounded to three decimals.

**What to say:** “Recall tells me whether I retrieved the reference evidence. It does not tell me whether Qwen interpreted that evidence correctly, whether its citations support each claim, or whether the final answer is fluent.” The 0.05 threshold is the value in your implementation; this guide does not re-audit subject requirements.

## 12 — HTTP API and error handling

[`api.py`](../src/api.py) creates `app = FastAPI()`. Uvicorn serves this ASGI application. Routes are synchronous `def` functions.

| Route | Behavior | Response |
|---|---|---|
| `GET /health` | Simple liveness response; does not validate indexes/model readiness | `{"status":"ok"}` |
| `POST /search` | Validate request and call the shared retrieval pipeline | One `MinimalSearchResults` object |
| `POST /answer` | Retrieve and optionally generate with the same Qwen helpers | One `MinimalAnswer` object |

Example request body: `{"query":"What controls deferred Pythonization?","k":5,"method":"bm25"}`. All three fields are required by `QueryRequest`, even though internal helper functions have defaults. API responses are single objects rather than the CLI's `search_results` wrapper.

FastAPI/Pydantic handles invalid request schemas as validation errors. The handlers catch `FileNotFoundError` and raise HTTP 503. They do not currently translate every stale-index `ValueError` or model runtime exception into a custom HTTP response. There is no indexing or evaluation HTTP endpoint in the inspected code.

## 13–14 — Library responsibilities

| Library | Functions/classes used | Why it is here |
|---|---|---|
| Python Fire | `Fire(RagCLI)` | Turn methods into command-line commands |
| Pydantic | `BaseModel`, `Field`, `field_validator`, `ValidationError`, validation/dump methods | Define JSON contracts, parse input and serialize output |
| langchain-text-splitters | `PythonCodeTextSplitter`, `create_documents()` | Split Python text while exposing source positions |
| tqdm | `tqdm()` | Progress bars for discovery and dataset loops |
| sentence-transformers | `SentenceTransformer`, `encode_document`, `encode`, `encode_query`, `similarity` | Produce and compare retrieval embeddings |
| NumPy | `stack`, `empty`, `astype`, `save`, `load` | Arrange, type and persist vector matrices |
| Transformers | `AutoTokenizer`, `AutoModelForCausalLM`, chat template, `generate`, `decode` | Load Qwen, format input and generate/decode tokens |
| PyTorch | `float32`, `inference_mode`, `topk`, model device/evaluation methods | Execute tensor computation and choose top vector matches |
| FastAPI | `FastAPI`, route decorators, `HTTPException` | Request routing, validation and HTTP error responses |
| Uvicorn | Server command | Run the ASGI application; not imported into the pipeline |
| flake8 / mypy | Development tooling | Style/static analysis; not runtime retrieval or generation |

The type imports `List`, `Dict`, `Tuple`, `Any`, `Literal`, `PreTrainedModel`, and `PreTrainedTokenizerBase` document expected shapes/interfaces. Type annotations alone do not perform general runtime validation; Pydantic and explicit checks provide that behavior at selected boundaries.

| Standard-library module | Actual role |
|---|---|
| `pathlib.Path` | Paths, recursive file discovery, reading/writing, directory creation |
| `os.path.relpath` | Store corpus paths relative to the working directory |
| `json` | Read/write datasets, chunks, hashes, metadata and cached results |
| `hashlib.sha256` | File fingerprints, stable chunk IDs and query cache keys |
| `uuid.uuid4` | New index revisions and default question IDs |
| `re.findall` | Lexical tokenization and full snake_case identifiers |
| `collections.Counter` | Per-chunk token frequencies |
| `collections.defaultdict(float)` | Accumulate hybrid scores starting from zero |
| `math.log` | BM25 inverse document frequency |
| `functools.lru_cache` | Reuse parsed indexes and loaded models within one process |
| `sys.stderr` | CLI error output |

## 15 — Worked journey and useful defense questions

For “What controls deferred Pythonization?”, the program tokenizes the question, ranks source chunks, and sends selected evidence to Qwen. If the retrieved code contains `if not sampling_metadata.skip_sampler_cpu_output`, the answer should preserve the negation and explain both branches. Finding that code and correctly explaining it are different accomplishments. `[Source 1]` refers to the first chunk in that request's context, not a permanent chunk ID.

| Peer question | Answer grounded in your implementation |
|---|---|
| Why chunks? | They bound the source spans and the amount of context, while retaining exact source locations. |
| Why three retrieval methods? | BM25 matches lexical terms; MiniLM compares text representations; RRF combines ranked candidates. |
| Why include the filename/path? | BM25 adds the basename to tokens; semantic encoding prepends the path to provide extra retrieval context. |
| How do vectors map back to code? | Row index → manifest chunk ID → current Chunk. |
| What makes indexing incremental? | Reuse unchanged chunks/postings/vectors; recompute changed content and remove deleted content. |
| What makes a cached query safe after updates? | Index revision is part of both the cache key and directory. |
| Does caching make every answer instant? | No. Qwen generation still runs; only retrieval results and loaded models are cached. |
| Are all citations verified? | No. The prompt requests citations, but no post-generation claim validator checks them. |
| Does semantic always return relevant evidence? | No explicit similarity threshold is applied; it returns the top available vectors. |
| Why can good recall coexist with wrong answers? | The generator may misread conditions, omit details or invent an explanation despite receiving the right source. |
| Is Qwen fine-tuned here? | No. The project loads pretrained weights and performs inference. |
| Does the CLI run as the vLLM inference server? | No. vLLM is the corpus being queried; Qwen runs through Transformers/PyTorch in this application. |

## Saved files you should be able to explain

| File | Meaning |
|---|---|
| `data/processed/chunks.json` | Full chunk text and source locations |
| `data/processed/map.json` | Path-to-file-hash map plus chunk-size setting |
| `data/processed/bm25.json` | Lengths, chunk term counts and inverted postings |
| `data/processed/metadata.json` | Current index revision UUID |
| `data/processed/semantic/embeddings.npy` | Vector matrix in manifest order |
| `data/processed/semantic/manifest.json` | Revision, model name, dimension, ordered chunk IDs |
| `data/processed/cache/queries/<revision>/<hash>.json` | Cached ranked chunks for a specific retrieval request |
| `data/output/...` | Saved search and answer results |

## Suggested presentation route

Start with diagram 01 and the opening explanation. Use 02–04 to explain indexing and BM25, 05–08 for the semantic/incremental/cache features, and 09–12 for answers, datasets, recall and HTTP. Use 13–14 when asked which libraries do which work. Finish by tracing one answer back to its source using diagram 15. For a shorter presentation, show 01, 03, 04, 05, 09 and 11, and keep the remaining diagrams for questions.

Examples to demonstrate from the repository root, using the project's installed environment:

```sh
.venv/bin/python -m src search "What controls deferred Pythonization?" --k=5 --method=bm25
.venv/bin/python -m src answer "What controls deferred Pythonization?" --k=5 --method=bm25
.venv/bin/python -m src search_dataset data/datasets/UnansweredQuestions/dataset_docs_public.json data/output/demo-search --k=5
.venv/bin/python -m src evaluate data/output/demo-search/dataset_docs_public.json data/datasets/AnsweredQuestions/dataset_docs_public.json --k=5
.venv/bin/python -m src answer_dataset data/output/demo-search/dataset_docs_public.json --save_directory=data/output/demo-answers
.venv/bin/python -m uvicorn src.api:app --host 127.0.0.1 --port 8000
```

These are demonstration commands, not commands executed while creating this guide. `answer_dataset` can take considerable time. Indexing with `--semantic=True` prepares semantic/hybrid retrieval; run it before demonstrating those methods if the semantic index is absent or stale.

The guide and presentation were created with AI assistance, based on the inspected source. Source behavior takes precedence if you later change the implementation.
